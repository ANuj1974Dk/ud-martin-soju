
export default function Home() {
  return (
    <main className="min-h-screen bg-[#f7f6f3] text-gray-800 font-sans">
      <header className="p-6 flex justify-between items-center shadow-md bg-white">
        <h1 className="text-2xl font-bold text-green-700">UD Martin Soju</h1>
        <nav className="space-x-4">
          <a href="#about" className="hover:text-green-700">About</a>
          <a href="#products" className="hover:text-green-700">Our Soju</a>
          <a href="#process" className="hover:text-green-700">How It's Made</a>
          <a href="#contact" className="hover:text-green-700">Contact</a>
        </nav>
      </header>

      <section className="text-center py-16 px-6 bg-gradient-to-b from-green-50 to-white">
        <h2 className="text-4xl font-semibold mb-4">India’s First Soju Brand</h2>
        <p className="text-lg text-gray-600 mb-6">Inspired by Korean tradition, crafted for modern India.</p>
        <button className="bg-green-700 text-white px-6 py-2 rounded-xl shadow-md hover:bg-green-800">Explore Flavors</button>
      </section>

      <section id="about" className="py-16 px-6 max-w-4xl mx-auto">
        <h3 className="text-3xl font-semibold mb-4 text-green-700">Our Story</h3>
        <p className="text-gray-700 text-lg">UD Martin Soju was born from a love for fermentation, flavor, and culture. As Indian palates explore new tastes, we bring the smooth, sessionable Korean spirit to India with a local twist.</p>
      </section>

      <section id="products" className="py-16 px-6 bg-green-50">
        <h3 className="text-3xl font-semibold text-center text-green-700 mb-10">Our Soju Collection</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8 max-w-6xl mx-auto">
          {['Original', 'Peach', 'Green Grape', 'Lychee'].map((flavor) => (
            <div key={flavor} className="bg-white rounded-2xl shadow p-4 text-center">
              <div className="h-40 bg-gray-200 rounded mb-4"></div>
              <h4 className="font-semibold text-xl mb-1">{flavor}</h4>
              <p className="text-sm text-gray-500">Smooth, light and flavorful</p>
            </div>
          ))}
        </div>
      </section>

      <section id="process" className="py-16 px-6 max-w-4xl mx-auto">
        <h3 className="text-3xl font-semibold mb-4 text-green-700">How It’s Made</h3>
        <p className="text-gray-700 text-lg mb-2">Crafted using tapioca, molasses, and rice—UD Martin Soju is distilled, flavored, and filtered with precision. Inspired by Korea. Made in India.</p>
      </section>

      <section id="contact" className="py-16 px-6 bg-green-50">
        <h3 className="text-3xl font-semibold text-center text-green-700 mb-6">Get in Touch</h3>
        <div className="max-w-xl mx-auto text-center">
          <p className="text-gray-700 mb-4">Want to collaborate, invest, or distribute UD Martin Soju?</p>
          <p className="text-gray-700 font-medium">Email us at <a href="mailto:anuj2977013@gmail.com" className="text-green-700 underline">anuj2977013@gmail.com</a></p>
        </div>
      </section>

      <footer className="text-center py-6 bg-white text-gray-500 text-sm">
        © 2025 UD Martin Soju. All rights reserved.
      </footer>
    </main>
  );
}
